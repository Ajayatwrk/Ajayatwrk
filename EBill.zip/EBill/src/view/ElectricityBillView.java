package view;

import controller.ElectricityBillController;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class ElectricityBillView {
    private ElectricityBillController controller;
    private JFrame frame;
    private JTextField unitsField;
    private JTextField customerIdField;

    public ElectricityBillView() {
        controller = new ElectricityBillController();
        frame = new JFrame("Electricity Bill Calculator");
        frame.setSize(400, 300);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setResizable(false);

        // Set background image or color
        ImageIcon backgroundIcon = new ImageIcon("images/I1.jpg");
        JLabel backgroundLabel = new JLabel(backgroundIcon);
        backgroundLabel.setLayout(new BorderLayout());

        JPanel panel = new JPanel(new GridLayout(3, 2));
        panel.setOpaque(false); // Make panel transparent

        panel.setBorder(BorderFactory.createEmptyBorder(50, 20, 50, 20)); // Adjust border as needed

        JLabel unitsLabel = new JLabel("Units Consumed:");
        unitsLabel.setForeground(Color.BLACK); // Set label text color
        panel.add(unitsLabel);

        unitsField = new JTextField();
        unitsField.setPreferredSize(new Dimension(100, 25));
        panel.add(unitsField);

        JLabel customerIdLabel = new JLabel("Customer ID:");
        customerIdLabel.setForeground(Color.BLACK);
        panel.add(customerIdLabel);

        customerIdField = new JTextField();
        customerIdField.setPreferredSize(new Dimension(100, 25));
        panel.add(customerIdField);

        JButton calculateButton = new JButton("Calculate and Save Bill");
        calculateButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    int unitsConsumed = Integer.parseInt(unitsField.getText());
                    int customerId = Integer.parseInt(customerIdField.getText());
                    double totalAmount = controller.calculateBill(unitsConsumed);
                    controller.saveBill(customerId, unitsConsumed, totalAmount);
                    JOptionPane.showMessageDialog(frame,
                            String.format("Total Bill Amount: Rs.%.2f", totalAmount),
                            "Bill Amount",
                            JOptionPane.INFORMATION_MESSAGE);
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(frame,
                            "Please enter valid units and customer ID",
                            "Input Error",
                            JOptionPane.ERROR_MESSAGE);
                }
            }
        });
        panel.add(calculateButton);

        backgroundLabel.add(panel, BorderLayout.CENTER);
        frame.setContentPane(backgroundLabel);
        frame.setVisible(true);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                new ElectricityBillView();
            }
        });
    }
}