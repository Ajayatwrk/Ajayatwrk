package view;

import controller.LoginController;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class LoginView {
    private LoginController controller;
    private JFrame frame;
    private JTextField usernameField;
    private JPasswordField passwordField;

    public LoginView() {
        controller = new LoginController();
        frame = new JFrame("Login");
        frame.setSize(1000, 625); // Set frame size
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setResizable(false);

        JPanel panel = new JPanel(new GridLayout(1, 2));

        // Left panel for image (placeholder)
        JPanel leftPanel = new JPanel(new BorderLayout());
        leftPanel.setBackground(Color.WHITE); // Set background color

        // Load and scale the image (replace with your image logic)
        ImageIcon imageIcon = new ImageIcon("images/I1.jpg"); // Replace with your image path
        Image image = imageIcon.getImage().getScaledInstance(500, 500, Image.SCALE_SMOOTH);
        ImageIcon scaledImageIcon = new ImageIcon(image);
        JLabel imageLabel = new JLabel(scaledImageIcon);
        leftPanel.add(imageLabel, BorderLayout.CENTER);
        panel.add(leftPanel);

        // Right panel for login components
        JPanel rightPanel = new JPanel(new GridBagLayout());
        rightPanel.setBackground(Color.WHITE); // Set background color
        rightPanel.setBorder(BorderFactory.createEmptyBorder(70, 20, 70, 20)); // Adjust border as needed

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.anchor = GridBagConstraints.LINE_END;
        gbc.insets = new Insets(5, 5, 5, 5);

        JLabel accnameLabel = new JLabel("Account Name:");
        accnameLabel.setForeground(Color.BLACK); // Set label text color to black
        rightPanel.add(accnameLabel, gbc);

        gbc.gridy++;
        JLabel accnoLabel = new JLabel("Acc No:");
        accnoLabel.setForeground(Color.BLACK); // Set label text color to black
        rightPanel.add(accnoLabel, gbc);

        gbc.gridx = 1;
        gbc.gridy = 0;
        gbc.anchor = GridBagConstraints.LINE_START;
        JTextField u1 = new JTextField(15); // Set preferred width for username field (adjust as needed)
        rightPanel.add(u1, gbc);

        gbc.gridy++;
        JTextField u2 = new JTextField(15); // Set preferred width for password field (adjust as needed)
        rightPanel.add(u2, gbc);

        gbc.gridy++;
        gbc.gridx = 0;
        gbc.gridwidth = 2;
        gbc.anchor = GridBagConstraints.CENTER;

        JButton cancelButton = new JButton("Cancel");
        cancelButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                frame.dispose(); // Close the login window
            }
        });
        rightPanel.add(cancelButton, gbc);

        gbc.gridy++;
        JButton loginButton = new JButton("Login");
        loginButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String name = u1.getText();
                String no = u2.getText();
                if (controller.authenticateUser(name, no)) {
                    // Open new ElectricityBillView upon successful login
                    new ElectricityBillView();
                    frame.dispose(); // Close the login window
                } else {
                    // Handle invalid login
                    JOptionPane.showMessageDialog(frame, "Invalid Name or Account number", "Login Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        });
        rightPanel.add(loginButton, gbc);

        panel.add(rightPanel);

        frame.setContentPane(panel);
        frame.setVisible(true);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                new LoginView();
            }
        });
    }
}
