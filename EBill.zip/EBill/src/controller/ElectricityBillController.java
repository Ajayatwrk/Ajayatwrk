package controller;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import connectivity.DBUtil;

public class ElectricityBillController {
    private Connection connection;

    public ElectricityBillController() {
        try {
            connection = DBUtil.getConnection();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public double calculateBill(int unitsConsumed) {
        // Example calculation logic (replace with your actual calculation logic)
        double ratePerUnit = 5.50; // Replace with your actual rate per unit
        return unitsConsumed * ratePerUnit;
    }

    public void saveBill(int customerId, int unitsConsumed, double totalAmount) {
        String query = "INSERT INTO customer (customer_id, units_consumed, total_amount) VALUES (?, ?, ?)";
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setInt(1, customerId);
            stmt.setInt(2, unitsConsumed);
            stmt.setDouble(3, totalAmount);
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
