package controller;


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import connectivity.DBUtil;

public class LoginController {
    private Connection connection;

    public LoginController() {
        try {
            connection = DBUtil.getConnection();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public boolean authenticateUser(String username, String password) {
        String query = "SELECT user_id FROM users WHERE username = ? AND password = ?";
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setString(1, username);
            stmt.setString(2, password);
            ResultSet rs = stmt.executeQuery();
            return rs.next(); // User authenticated if there's a matching record
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
}
/*controller.saveBill(customerId, unitsConsumed, totalAmount);*/