/**
 * 
 */
/**
 * 
 */
module EBill {
	requires java.desktop;
	requires java.sql;
}